#include <stdio.h>
#include <stdlib.h>

int foo(){
    int b = 5;
    char array[2];
    printf("please enter: \n");
    scanf("%s", array);

    return 0;
}

int main(){
    foo();
    return 0;
}
