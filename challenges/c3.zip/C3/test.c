#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

int main()
{
  char *param[] = {"/bin/sh", "-c", "/usr/bin/gedit", 0};
  execve("/bin/sh", param, NULL);
  //system("gedit");
  return 0;
}


// 0x8048424 <main+25>:	call   0x80482e0 <system@plt>
